<?php
// Book Shortcode Class
class WP_Book_Shortcode {
    public function __construct() {
        add_shortcode('book_shortcode', array($this, 'book_grid_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'book_enqueue_scripts'));

    }

    // Enqueue scripts
    public function book_enqueue_scripts() {
        wp_enqueue_style('wp-book-style', WPBTEMPLATEURL . '/wp-book/assest/css/style.css');
    }

    // Book Grid Shortcode
    public function book_grid_shortcode($atts) {
        $atts = shortcode_atts(array(
            'limit' => -1,
            'show_subtitle' => false,
        ), $atts);

        $args = array(
            'post_type' => 'book',
            'posts_per_page' => intval($atts['limit']),
            'orderby' => 'title',
            'order' => 'ASC',
            'post_status' => 'publish'
        );

        $query = new WP_Query($args);

        ob_start();
        if ($query->have_posts()) {
            echo '<div class="book-grid">';
            while ($query->have_posts()) {
                $query->the_post();
                $subtitle = '';
                if ($atts['show_subtitle'] === 'true') {
                    $subtitle = get_post_meta(get_the_ID(), 'book_subtitle', true);
                }
                echo '<div class="book-item">';
                if (!empty(get_post_meta(get_the_ID(), 'book_second_cover_image', true))) {
                    echo '<img src="' . esc_url(get_post_meta(get_the_ID(), 'book_second_cover_image', true)) . '" alt="' . esc_attr(get_the_title()) . '">';
                }
                echo '<h3>' . get_the_title() . '</h3>';
                if (!empty($subtitle)) {
                    echo '<p class="book-subtitle">' . esc_html($subtitle) . '</p>';
                }
                echo '</div>';
                }
                echo '</div>';
            wp_reset_postdata();
        } else {
            echo 'No books found.';
        }
        return ob_get_clean();
    }
}