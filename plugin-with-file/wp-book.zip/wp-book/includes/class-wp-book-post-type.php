<?php
// Register Custom Post Type
class WP_Book_Register_Post_Type {
    public function __construct() {
        add_action('init', array($this, 'wp_custom_post_type'));
        add_action('add_meta_boxes', array($this, 'book_add_custom_fields_metabox'));
        add_action('save_post', array($this, 'book_save_custom_fields'));
        add_action('admin_enqueue_scripts', array($this, 'book_admin_enqueue_scripts'));
    }

    // Register custom post type Book
    public function wp_custom_post_type() {

        // Set UI labels for Custom Post Type
        $labels = array(
            'name'                => _x( 'Books', 'wp-book' ),
            'singular_name'       => _x( 'Book', 'wp-book' ),
            'menu_name'           => __( 'Books', 'wp-book' ),
            'parent_item_colon'   => __( 'Parent Book', 'wp-book' ),
            'all_items'           => __( 'All Books', 'wp-book' ),
            'view_item'           => __( 'View Book', 'wp-book' ),
            'add_new_item'        => __( 'Add New Book', 'wp-book' ),
            'add_new'             => __( 'Add New', 'wp-book' ),
            'edit_item'           => __( 'Edit Book', 'wp-book' ),
            'update_item'         => __( 'Update Book', 'wp-book' ),
            'search_items'        => __( 'Search Book', 'wp-book' ),
            'not_found'           => __( 'Not Found', 'wp-book' ),
            'not_found_in_trash'  => __( 'Not found in Trash', 'wp-book' ),
        );

        // Set other options for Custom Post Type
        $args = array(
            'labels'              => $labels,
            'supports'            => array( 'title', 'editor', 'thumbnail'),
            'hierarchical'        => true,
            'menu_icon'           => 'dashicons-book',
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'rewrite'             => array( 'slug' => 'book'),
            'capability_type'     => 'post',
            'menu_position'       => 5,
            'has_archive'         => true,
        );

        register_post_type('book', $args);

        // Register Taxonomy 
        register_taxonomy('book_category', 'book',
            array(
                'label' => 'Books Categories',
                'hierarchical' => true,
                'rewrite' => array('slug' => 'book-category'),
            )
        );
    }

    function book_admin_enqueue_scripts() {
        // Enqueue necessary styles and scripts
        wp_enqueue_style('wp-book-admin-style', WPBTEMPLATEURL . '/wp-book/assest/css/admin-style.css');
        wp_enqueue_script( 'wp-book-admin-script', WPBTEMPLATEURL .'/wp-book/assest/js/admin-script.js', array( 'jquery' ));
    }

    public function book_add_custom_fields_metabox() {
        add_meta_box(
            'book_custom_fields',
            'Book Custom Fields',
            array($this, 'book_render_custom_fields_metabox'),
            'book',
            'normal',
            'default'
        );
    }

    public function book_render_custom_fields_metabox($post) {
        wp_nonce_field('book_custom_fields_nonce', 'book_custom_fields_nonce');

        $book_subtitle              = get_post_meta($post->ID, 'book_subtitle', true);
        $book_rating                = get_post_meta($post->ID, 'book_rating', true);
        $book_second_cover_image    = get_post_meta($post->ID, 'book_second_cover_image', true);
        ?>

        <label for="book_subtitle">Book Sub Title:</label>
        <input type="text" id="book_subtitle" name="book_subtitle" value="<?php echo esc_attr($book_subtitle); ?>"><br>
    
        <label for="book_rating">Book Rating:</label>
        <select id="book_rating" name="book_rating">
            <?php
            for ($i = 0; $i <= 5; $i++) {
                echo '<option value="' . $i . '" ' . selected($book_rating, $i, false) . '>' . $i . '</option>';
            }
            ?>
        </select><br>
    
        <label for="book_second_cover_image">Book Second Cover Image:</label>
        <br>
        <img id="book_second_cover_image_preview" src="<?php echo esc_attr($book_second_cover_image); ?>" alt="Second Cover Image Preview" style="display: <?php echo empty($book_second_cover_image) ? 'none' : 'block'; ?>;"><br>
        <input type="text" id="book_second_cover_image" name="book_second_cover_image" value="<?php echo esc_attr($book_second_cover_image); ?>" style="display: none;">
        <input type="button" id="upload_second_cover_image_button" class="button" value="Upload Image">
        <input type="button" id="remove_second_cover_image_button" class="button" value="Remove Image" <?php echo empty($book_second_cover_image) ? 'style="display: none;"' : ''; ?>>
        <br>
        <?php
    }

    public function book_save_custom_fields($post_id) {
        if (!isset($_POST['book_custom_fields_nonce'])) {
            return;
        }
    
        if (!wp_verify_nonce($_POST['book_custom_fields_nonce'], 'book_custom_fields_nonce')) {
            return;
        }
    
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
    
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    
        if (isset($_POST['book_subtitle'])) {
            update_post_meta($post_id, 'book_subtitle', sanitize_text_field($_POST['book_subtitle']));
        }
    
        if (isset($_POST['book_rating'])) {
            update_post_meta($post_id, 'book_rating', intval($_POST['book_rating']));
        }
    
        if (isset($_POST['book_second_cover_image'])) {
            update_post_meta($post_id, 'book_second_cover_image', sanitize_text_field($_POST['book_second_cover_image']));
        }
    }
}