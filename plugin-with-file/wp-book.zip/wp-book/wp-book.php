<?php
/**  
 * Plugin Name: WP Book
 * Description: This plugin will add a Custom post type and functionality.
 * Plugin URI: https://developer.wordpress.org/
 * Version: 1.0.1
 * Author: Balvant WordPress Developer
 * Author URI: https://developer.wordpress.org/
 * Text Domain: wp-book
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

define( 'WPBTEMPLATEPATH', plugin_dir_path( __FILE__ ) );
define( 'WPBTEMPLATEURL', plugins_url() );

include_once('includes/class-wp-book-post-type.php');
include_once('includes/class-wp-book-shortcode.php');

// Initialize the Class
new WP_Book_Register_Post_Type();
new WP_Book_Shortcode();