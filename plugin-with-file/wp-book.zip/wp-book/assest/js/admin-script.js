jQuery(document).ready(function($) {
    $('#upload_second_cover_image_button').click(function() {
        var customUploader = wp.media({
            title: 'Choose an Image',
            button: {
                text: 'Use this Image'
            },
            multiple: false
        });

        customUploader.on('select', function() {
            var attachment = customUploader.state().get('selection').first().toJSON();
            $('#book_second_cover_image').val(attachment.url);

            // Update the image preview
            $('#book_second_cover_image_preview').attr('src', attachment.url).show();
            $('#remove_second_cover_image_button').show();
        });

        customUploader.open();
    });

    $('#remove_second_cover_image_button').click(function() {
        $('#book_second_cover_image').val('');
        $('#book_second_cover_image_preview').attr('src', '').hide();
        $(this).hide();
    });
});